#!/bin/sh
#ServiceSript 
#CodedBy DroPZsec
#

#COLORED_OUTPUT

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

# MENU CODE

clear
    sleep 1.0
echo $green "Loading Service Menu..." $reset 
    sleep 1.0
clear
    sleep 0.25
echo $orange 
figlet -f small "System Service Menu"
echo "" $reset 
echo "" 
echo ""
echo ""
echo "" 
echo $blue"1."$reset $orange")"$reset $green "Start PostgreSQL" $reset 
    sleep 0.25
echo $blue"2."$reset $orange")"$reset $green "Stop PostgreSQL" $reset 
    sleep 0.25
echo $blue"3."$reset $orange")"$reset $green "Start Metasploit-Service" $reset 
    sleep 0.25
echo $blue"4."$reset $orange")"$reset $green "Stop Metasploit-Service" $reset 
    sleep 0.25
echo $blue"5."$reset $orange")"$reset $green "Start TOR Service" $reset 
    sleep 0.25
echo $blue"6."$reset $orange")"$reset $green "Stop TOR Service" $reset 
    sleep 0.25
echo $blue"7."$reset $orange")"$reset $green "Start NGINX Service" $reset 
    sleep 0.25
echo $blue"8."$reset $orange")"$reset $green "Stop NGINX Service" $reset 
    sleep 0.25
echo $blue"9."$reset $orange")"$reset $green "List status of all Services" $reset 
    sleep 0.25
echo $blue"10."$reset $orange")"$reset $green "EXIT" $reset 
    sleep 0.25
echo $green "Enter your choice:" $reset
    read answer;

if [ $answer = 1 ]; then
    sudo service postgresql start 
    echo $green "Service Postgresql is now running!"
    echo "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 2 ]; then 
    sudo service postgresql stop
    echo $green "Service Postgresql is now deactivated!"
    echo "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 3 ]; then
    sudo service metasploit start 
    echo $green "Service Metasploit is running now!"
    echo "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 4 ]; then 
    sudo service metasploit stop 
    echo $green "Service Metasploit is deactivated now!"
    echo "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 5 ]; then 
    sudo service tor start 
    echo $green "Service TOR is running now!" 
    echo "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 6 ]; then 
    sudo service tor stop 
    echo $green "Service TOR is deactivated now!"
    echo "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 7 ]; then 
    sudo service nginx start
    echo $green "Service NGNINX is running now!"
    echo "Press ENTER to continue..." $reset
        read enter;
fi 
if [ $answer = 8 ]; then 
    sudo service nginx stop
    echo $green "Service NGINX is deactivated now!"
    echo "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 9 ]; then
    service --status-all
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 10 ]; then 
     echo $green "OK, Youre Choice..."
        sleep 1.0
    clear
    echo $blue
    figlet -f small "System Service Script"
        sleep 0.5 
    figlet -f small "coded by:"
    echo $reset $orange 
        sleep 1.0 
    figlet -f big "vDroPZz"
        sleep 1.0
    clear 
    echo $reset $blue  
    figlet -f small "Follow me on Github:"
    echo $reset $orange 
        sleep 0.5 
    figlet -f big "DroPZsec"
        sleep 1.5 
    clear 
    echo $reset 
    cd ..
    ./BashAttack.sh
fi 
./services.sh 
/bin/sh 